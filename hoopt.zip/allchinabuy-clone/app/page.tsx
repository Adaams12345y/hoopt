import { HeroSection } from '@/components/hero-section'
import { TopSellers } from '@/components/top-sellers'
import { BrandCarousel } from '@/components/brand-carousel'
import { InfoSection } from '@/components/info-section'
import { Newsletter } from '@/components/newsletter'

export default function Home() {
  return (
    <>
      <HeroSection />
      <TopSellers />
      <BrandCarousel />
      <InfoSection />
      <Newsletter />
    </>
  )
}

