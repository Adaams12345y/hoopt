'use client'

import { useState } from 'react'
import { Grid2X2, Grid3X3, Grid2x2XIcon as Grid4X4 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { ProductCard } from '@/components/product-card'

export default function WishlistPage() {
  const [viewMode, setViewMode] = useState(3)
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-bold">Wish List</h1>
        <div className="flex items-center space-x-2">
          <span className="text-sm">VIEW AS</span>
          <div className="flex border rounded-lg">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setViewMode(2)}
              className={viewMode === 2 ? 'bg-orange-500 text-white' : ''}
            >
              <Grid2X2 className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setViewMode(3)}
              className={viewMode === 3 ? 'bg-orange-500 text-white' : ''}
            >
              <Grid3X3 className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setViewMode(4)}
              className={viewMode === 4 ? 'bg-orange-500 text-white' : ''}
            >
              <Grid4X4 className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
      
      <div className={`grid grid-cols-${viewMode} gap-6`}>
        {/* Wishlist items will be mapped here */}
      </div>
    </div>
  )
}

