import Image from 'next/image'
import Link from 'next/link'
import { Flame, Heart } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { products } from '@/lib/products'

export default function ProductPage({ params }: { params: { id: string } }) {
  // For demo purposes, using first product
  const product = {
    id: 'louis-vuitton-jacket',
    title: "Louis Vuitton Bunny Varsity College Jacket Cream",
    price: 38.00,
    image: "/placeholder.svg?height=600&width=600",
    thumbnail: "/placeholder.svg?height=100&width=100",
    soldCount: 404,
    soldTime: 1
  }

  const relatedProducts = [
    {
      id: 'product-1',
      title: "Product 1",
      price: 99.00,
      image: "/placeholder.svg?height=300&width=300",
      isNew: true
    },
    // Add more related products
  ]

  return (
    <div className="min-h-screen bg-black">
      <div className="container px-4 py-8">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-sm mb-8">
          <Link href="/" className="text-gray-400 hover:text-white">Home</Link>
          <span className="text-gray-600">/</span>
          <Link href="/products" className="text-gray-400 hover:text-white">Products</Link>
          <span className="text-gray-600">/</span>
          <span className="text-white">{product.title}</span>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          {/* Product Images */}
          <div className="space-y-4">
            <div className="aspect-square relative overflow-hidden rounded-lg border border-gray-800">
              <Image
                src={product.image}
                alt={product.title}
                fill
                className="object-cover"
              />
            </div>
            <div className="grid grid-cols-5 gap-4">
              <button className="aspect-square relative overflow-hidden rounded-lg border border-gray-800">
                <Image
                  src={product.thumbnail}
                  alt="Thumbnail"
                  fill
                  className="object-cover"
                />
              </button>
            </div>
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <h1 className="text-3xl font-bold">{product.title}</h1>
            <div className="flex items-center gap-2 text-[#ff9300]">
              <Flame className="w-5 h-5" />
              <span>{product.soldCount} sold in last {product.soldTime} hours</span>
            </div>
            <div className="text-3xl font-bold">€{product.price.toFixed(2)} EUR</div>
            <div className="flex gap-4">
              <Button className="flex-1 bg-[#ff9300] text-black hover:bg-[#4BC0C3]">
                Buy On Hoobuy
              </Button>
              <Button variant="outline" size="icon" className="border-[#ff9300]">
                <Heart className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>

        {/* Related Products */}
        <div className="mt-16">
          <h2 className="text-2xl font-bold mb-8">Related Products</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {relatedProducts.map((product) => (
              <div key={product.id} className="group">
                <div className="relative aspect-square overflow-hidden rounded-lg border border-gray-800">
                  <Image
                    src={product.image}
                    alt={product.title}
                    fill
                    className="object-cover transition-transform group-hover:scale-105"
                  />
                  {product.isNew && (
                    <span className="absolute top-2 left-2 bg-[#ff9300] text-black px-2 py-1 text-xs font-bold rounded">
                      New
                    </span>
                  )}
                </div>
                <div className="mt-4 space-y-2">
                  <h3 className="text-sm font-medium">{product.title}</h3>
                  <p className="text-lg font-bold">€{product.price.toFixed(2)} EUR</p>
                  <Button className="w-full bg-[#ff9300] text-black hover:bg-[#4BC0C3]">
                    Buy On Hoobuy
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

