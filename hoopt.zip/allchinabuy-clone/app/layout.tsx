import { Inter } from 'next/font/google'
import './globals.css'
import { Header } from '@/components/header'
import { createClient } from '@/lib/auth'

const inter = Inter({ subsets: ['latin'] })

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const supabase = await createClient()
  const {
    data: { session },
  } = await supabase.auth.getSession()

  return (
    <html lang="en">
      <body className={inter.className}>
        <Header user={session?.user} />
        <main>{children}</main>
      </body>
    </html>
  )
}

