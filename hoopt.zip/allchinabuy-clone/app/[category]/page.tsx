import { ProductGrid } from '@/components/product-grid'
import { FilterSidebar } from '@/components/filter-sidebar'
import { products, type Category } from '@/lib/products'

export function generateStaticParams() {
  return Object.keys(products).map((category) => ({
    category,
  }))
}

export default function CategoryPage({
  params
}: {
  params: { category: Category }
}) {
  const categoryProducts = products[params.category] || []

  return (
    <div className="container px-4 py-8">
      <div className="flex flex-col md:flex-row gap-8">
        <aside className="w-full md:w-64">
          <FilterSidebar />
        </aside>
        <main className="flex-1">
          <ProductGrid products={categoryProducts} />
        </main>
      </div>
    </div>
  )
}

