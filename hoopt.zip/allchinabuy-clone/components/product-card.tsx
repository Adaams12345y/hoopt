import Link from 'next/link'
import Image from 'next/image'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import type { Product } from '@/lib/products'

interface ProductCardProps extends Product {}

export function ProductCard({ id, title, price, image, isNew }: ProductCardProps) {
  return (
    <Link href={`/products/${id}`} className="group relative block">
      <div className="relative aspect-square overflow-hidden rounded-lg bg-gray-900">
        <Image
          src={image || "/placeholder.svg?height=400&width=400"}
          alt={title}
          width={400}
          height={400}
          className="object-cover transition-transform duration-300 group-hover:scale-105"
        />
        {isNew && (
          <Badge className="absolute left-2 top-2 bg-[#ff9300] text-black">
            New
          </Badge>
        )}
      </div>
      <div className="mt-4 space-y-2">
        <h3 className="text-sm font-medium group-hover:text-[#5CD3D6]">{title}</h3>
        <p className="text-lg font-bold">€{price.toFixed(2)} EUR</p>
        <Button className="w-full bg-[#ff9300] text-black hover:bg-[#4BC0C3]">
          Buy On Hoobuy
        </Button>
      </div>
    </Link>
  )
}

