import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

export function Newsletter() {
  return (
    <section className="py-16 bg-black border-t border-gray-800">
      <div className="container px-4 text-center">
        <h2 className="text-2xl font-bold mb-2">SUBSCRIBE TO OUR NEWSLETTER!</h2>
        <p className="text-gray-400 mb-8">
          Get the latest updates on new upcoming products and links!
        </p>
        <form className="max-w-md mx-auto flex gap-4">
          <Input
            type="email"
            placeholder="enter your email address here"
            className="bg-transparent border-gray-800"
          />
          <Button type="submit" variant="outline">
            Submit
          </Button>
        </form>
      </div>
    </section>
  )
}

