import Link from 'next/link'

const categories = [
  'Electronic',
  'Jackets',
  'Vests',
  'Pants',
  'Hoodies',
  'Shoes',
  'Sweater',
  'Trackies',
  'Jerseys',
  'T-Shirts',
  'Shorts',
  'Bags',
  'Hats',
]

export function MainNav() {
  return (
    <nav className="flex items-center space-x-6 mt-4">
      <button className="flex items-center space-x-1">
        <span className="text-sm">Categories</span>
      </button>
      <div className="flex items-center space-x-4 overflow-x-auto">
        {categories.map((category) => (
          <Link
            key={category}
            href={`/category/${category.toLowerCase()}`}
            className="text-sm text-gray-300 hover:text-white whitespace-nowrap"
          >
            {category}
          </Link>
        ))}
      </div>
    </nav>
  )
}

