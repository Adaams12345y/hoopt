'use client'

import { Slider } from '@/components/ui/slider'
import { Checkbox } from '@/components/ui/checkbox'
import { Button } from '@/components/ui/button'

export function FilterSidebar() {
  return (
    <div className="space-y-8">
      <div>
        <h3 className="font-bold mb-4">PREIS</h3>
        <Slider
          defaultValue={[0, 100]}
          max={100}
          step={1}
          className="mb-4"
        />
        <div className="flex gap-4 items-center">
          <div className="flex items-center">
            <span className="mr-2">€</span>
            <input
              type="number"
              className="w-20 bg-transparent border border-gray-800 rounded p-1"
            />
          </div>
          <span>to</span>
          <div className="flex items-center">
            <span className="mr-2">€</span>
            <input
              type="number"
              className="w-20 bg-transparent border border-gray-800 rounded p-1"
            />
          </div>
        </div>
        <Button className="w-full mt-4">Apply</Button>
      </div>

      <div>
        <h3 className="font-bold mb-4">COLOR</h3>
        <div className="flex flex-wrap gap-2">
          {['black', 'white', 'orange', 'red', 'gray'].map((color) => (
            <button
              key={color}
              className={`w-6 h-6 rounded-full border border-gray-600 bg-${color}`}
            />
          ))}
        </div>
      </div>

      <div>
        <h3 className="font-bold mb-4">BRAND</h3>
        <div className="space-y-2">
          {[
            { label: 'Apple', count: 18 },
            { label: 'Beats', count: 3 },
            { label: 'Bose', count: 2 },
            { label: 'Marshall', count: 6 },
            { label: 'Samsung', count: 2 },
          ].map((brand) => (
            <div key={brand.label} className="flex items-center">
              <Checkbox id={brand.label} />
              <label
                htmlFor={brand.label}
                className="ml-2 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                {brand.label} ({brand.count})
              </label>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

