import { Shield, Star, Warehouse, HelpCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'

const features = [
  {
    icon: Star,
    title: "QUALITY AND SAVING",
    description: "Best value for money!"
  },
  {
    icon: Warehouse,
    title: "QC PHOTOS",
    description: "for 100% transparency!"
  },
  {
    icon: Shield,
    title: "PAYMENT SECURITY",
    description: "More than 10 different secure payment methods!"
  },
  {
    icon: HelpCircle,
    title: "HAVE QUESTIONS?",
    description: "24/7 Customer Service - We're here and happy to help!"
  },
]

export function InfoSection() {
  return (
    <section className="py-16 bg-black">
      <div className="container px-4">
        <h2 className="text-3xl font-bold text-center mb-12">Why Our Links?</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature) => (
            <div
              key={feature.title}
              className="p-6 border border-gray-800 rounded-lg text-center"
            >
              <feature.icon className="w-8 h-8 mx-auto mb-4" />
              <h3 className="font-bold mb-2">{feature.title}</h3>
              <p className="text-gray-400">{feature.description}</p>
            </div>
          ))}
        </div>
        <div className="mt-12 text-center">
          <div className="max-w-md mx-auto space-y-4">
            <h3 className="text-lg font-bold">STILL DON'T HAVE A HOOBUY ACCOUNT?</h3>
            <p>Sign up to Hoobuy and get a 140$ coupon!</p>
            <Button variant="outline">CLICK HERE!</Button>
          </div>
        </div>
      </div>
    </section>
  )
}

