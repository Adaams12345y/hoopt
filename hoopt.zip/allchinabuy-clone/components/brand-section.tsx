import Image from 'next/image'

const brands = [
  { name: 'Apple', logo: '/placeholder.svg?height=100&width=100' },
  { name: 'Nike', logo: '/placeholder.svg?height=100&width=100' },
  { name: 'Jordan', logo: '/placeholder.svg?height=100&width=100' },
  { name: 'Adidas', logo: '/placeholder.svg?height=100&width=100' },
  { name: 'Gucci', logo: '/placeholder.svg?height=100&width=100' },
  { name: 'Prada', logo: '/placeholder.svg?height=100&width=100' },
]

export function BrandSection() {
  return (
    <section className="py-12 bg-black">
      <div className="container px-4">
        <h2 className="text-2xl font-bold mb-8">Top Brands</h2>
        <div className="grid grid-cols-3 md:grid-cols-6 gap-8">
          {brands.map((brand) => (
            <div
              key={brand.name}
              className="flex items-center justify-center"
            >
              <Image
                src={brand.logo}
                alt={brand.name}
                width={100}
                height={100}
                className="w-20 h-20 object-contain invert"
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

