'use client'

import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Search, Heart, User } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { MainNav } from './main-nav'
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs'

export function Header({ user }) {
  const router = useRouter()
  const supabase = createClientComponentClient()

  const handleSignOut = async () => {
    await supabase.auth.signOut()
    router.refresh()
  }

  return (
    <header className="border-b border-gray-800">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <span className="text-2xl font-bold text-[#ff9300]">Hoobuy</span>
          </Link>
          
          <div className="flex-1 max-w-2xl mx-4">
            <div className="relative">
              <Input
                placeholder="Search the store"
                className="w-full bg-transparent border-gray-700"
              />
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <Link href="/wishlist">
              <Button variant="ghost" className="relative">
                <Heart className="w-5 h-5 text-[#ff9300]" />
                <span className="absolute -top-1 -right-1 bg-[#ff9300] text-black text-xs rounded-full w-4 h-4 flex items-center justify-center">
                  0
                </span>
              </Button>
            </Link>
            {user ? (
              <div className="flex items-center space-x-4">
                <span className="text-sm">{user.email}</span>
                <Button variant="ghost" onClick={handleSignOut}>
                  Sign Out
                </Button>
              </div>
            ) : (
              <Link href="/auth/login">
                <Button variant="ghost">
                  <User className="w-5 h-5 mr-2" />
                  Sign In
                </Button>
              </Link>
            )}
          </div>
        </div>
        <MainNav />
      </div>
    </header>
  )
}

