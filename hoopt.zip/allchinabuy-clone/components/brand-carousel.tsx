'use client'

import { useEffect, useState } from 'react'
import Image from 'next/image'

const brands = [
  { name: 'Apple', logo: '/placeholder.svg?height=100&width=100' },
  { name: 'Nike', logo: '/placeholder.svg?height=100&width=100' },
  { name: 'Jordan', logo: '/placeholder.svg?height=100&width=100' },
  { name: 'Adidas', logo: '/placeholder.svg?height=100&width=100' },
  { name: 'Gucci', logo: '/placeholder.svg?height=100&width=100' },
  { name: 'Prada', logo: '/placeholder.svg?height=100&width=100' },
]

export function BrandCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((current) => (current + 1) % brands.length)
    }, 3000)

    return () => clearInterval(interval)
  }, [])

  return (
    <section className="py-12 bg-black overflow-hidden">
      <div className="container px-4">
        <h2 className="text-2xl font-bold mb-8">Top Brands</h2>
        <div className="relative">
          <div 
            className="flex transition-transform duration-500 ease-in-out"
            style={{ transform: `translateX(-${currentIndex * (100 / brands.length)}%)` }}
          >
            {[...brands, ...brands].map((brand, i) => (
              <div
                key={`${brand.name}-${i}`}
                className="flex-none w-1/6 px-4"
              >
                <div className="flex items-center justify-center">
                  <Image
                    src={brand.logo}
                    alt={brand.name}
                    width={100}
                    height={100}
                    className="w-20 h-20 object-contain invert"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

