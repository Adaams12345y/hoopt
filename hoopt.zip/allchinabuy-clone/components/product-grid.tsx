'use client'

import { useState } from 'react'
import { ProductCard } from './product-card'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import type { Product } from '@/lib/products'

interface ProductGridProps {
  products: Product[]
}

export function ProductGrid({ products }: ProductGridProps) {
  const [viewMode, setViewMode] = useState(4)

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center gap-4">
          <span>VIEW AS</span>
          <div className="flex gap-1">
            {[2, 3, 4, 5].map((cols) => (
              <button
                key={cols}
                onClick={() => setViewMode(cols)}
                className={`w-8 h-8 border border-gray-800 flex items-center justify-center ${
                  viewMode === cols ? 'bg-[#5CD3D6] text-black' : ''
                }`}
              >
                {cols}
              </button>
            ))}
          </div>
        </div>
        <div className="flex items-center gap-4">
          <Select defaultValue="20">
            <SelectTrigger className="w-20">
              <SelectValue placeholder="Items" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="20">20</SelectItem>
              <SelectItem value="40">40</SelectItem>
              <SelectItem value="60">60</SelectItem>
            </SelectContent>
          </Select>
          <Select defaultValue="alphabetical">
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="alphabetical">Alphabetical</SelectItem>
              <SelectItem value="price-asc">Price: Low to High</SelectItem>
              <SelectItem value="price-desc">Price: High to Low</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className={`grid grid-cols-${viewMode} gap-6`}>
        {products.map((product) => (
          <ProductCard key={product.id} {...product} />
        ))}
      </div>
    </div>
  )
}

