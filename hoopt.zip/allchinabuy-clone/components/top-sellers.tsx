'use client'

import { ChevronLeft, ChevronRight } from 'lucide-react'
import { ProductCard } from './product-card'
import { Button } from '@/components/ui/button'
import Link from 'next/link'

const products = [
  {
    title: "Ralph Lauren Shiny Puffer Jacket Black",
    price: 88.00,
    image: "/placeholder.svg?height=400&width=400",
  },
  {
    title: "Polo Ralph Lauren Zip Hoodie Black Red",
    price: 28.00,
    image: "/placeholder.svg?height=400&width=400",
    isNew: true,
  },
  {
    title: "Burberry Pufferjacket X Vest 2 In 1 Black",
    price: 103.00,
    image: "/placeholder.svg?height=400&width=400",
  },
  {
    title: "Louis Vuitton Bunny Varsity College Jacket Cream",
    price: 38.00,
    image: "/placeholder.svg?height=400&width=400",
  },
  {
    title: "Stussy Down Jacket Pink Black",
    price: 44.00,
    image: "/placeholder.svg?height=400&width=400",
  },
]

export function TopSellers() {
  return (
    <section className="relative">
      <div className="container px-4 py-12">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold">Current Top Sellers</h2>
          <Link href="/shop-all" className="text-[#ff9300] hover:underline">
            Shop All
          </Link>
        </div>
        <div className="relative">
          <div className="flex gap-6 overflow-x-auto pb-4 scrollbar-hide">
            {products.map((product, i) => (
              <div key={i} className="min-w-[280px]">
                <ProductCard {...product} />
              </div>
            ))}
          </div>
          <Button
            variant="outline"
            size="icon"
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 bg-black/50 rounded-full hidden md:flex"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 bg-black/50 rounded-full hidden md:flex"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </section>
  )
}

