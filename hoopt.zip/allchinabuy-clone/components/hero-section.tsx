import Image from 'next/image'
import { Button } from '@/components/ui/button'

export function HeroSection() {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="grid md:grid-cols-2 gap-8 items-center">
        <div className="space-y-6">
          <h1 className="text-5xl font-bold tracking-tight text-white glow-text">
            SIGN UP TO
            <br />
            HOOBUY
          </h1>
          <p className="text-4xl font-medium text-[#ff9300]">
            FOR A 140$ COUPON
          </p>
          <Button className="bg-[#ff9300] text-black hover:bg-[#4BC0C3]">
            CLICK HERE
          </Button>
        </div>
        <div className="text-center space-y-6">
          <h2 className="text-5xl font-bold tracking-tight text-white glow-text">
            THE
            <br />
            ULTIMATE
            <br />
            SPREADSHEET
          </h2>
          <div className="flex items-center justify-center space-x-4">
            <div className="w-16 h-16 rounded-full bg-red-600" />
            <div className="w-16 h-16">
              <Image
                src="/placeholder.svg"
                alt="X Logo"
                width={64}
                height={64}
                className="rounded-lg"
              />
            </div>
            <div className="w-16 h-16">
              <Image
                src="/placeholder.svg"
                alt="App Logo"
                width={64}
                height={64}
                className="rounded-lg"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

