export const products = {
  electronic: [
    {
      id: 'airpods-2',
      title: "Apple AirPods 2",
      price: 8.00,
      image: "/placeholder.svg?height=400&width=400"
    },
    // More electronic products...
  ],
  jackets: [
    {
      id: 'louis-vuitton-jacket',
      title: "Louis Vuitton Bunny Varsity College Jacket Cream",
      price: 38.00,
      image: "/placeholder.svg?height=400&width=400"
    },
    // More jackets...
  ],
  vests: [
    {
      id: 'vest-1',
      title: "Designer Vest Black",
      price: 45.00,
      image: "/placeholder.svg?height=400&width=400"
    },
    // More vests...
  ],
  pants: [
    {
      id: 'pants-1',
      title: "Designer Pants Black",
      price: 55.00,
      image: "/placeholder.svg?height=400&width=400"
    },
    // More pants...
  ],
  hoodies: [
    {
      id: 'hoodie-1',
      title: "Designer Hoodie Black",
      price: 65.00,
      image: "/placeholder.svg?height=400&width=400"
    },
    // More hoodies...
  ],
  shoes: [
    {
      id: 'shoes-1',
      title: "Designer Shoes Black",
      price: 75.00,
      image: "/placeholder.svg?height=400&width=400"
    },
    // More shoes...
  ],
  sweater: [
    {
      id: 'sweater-1',
      title: "Designer Sweater Black",
      price: 85.00,
      image: "/placeholder.svg?height=400&width=400"
    },
    // More sweaters...
  ],
  trackies: [
    {
      id: 'trackies-1',
      title: "Designer Tracksuit Black",
      price: 95.00,
      image: "/placeholder.svg?height=400&width=400"
    },
    // More trackies...
  ],
  jerseys: [
    {
      id: 'jersey-1',
      title: "Designer Jersey Black",
      price: 105.00,
      image: "/placeholder.svg?height=400&width=400"
    },
    // More jerseys...
  ],
  tshirts: [
    {
      id: 'tshirt-1',
      title: "Designer T-Shirt Black",
      price: 25.00,
      image: "/placeholder.svg?height=400&width=400"
    },
    // More t-shirts...
  ],
  shorts: [
    {
      id: 'shorts-1',
      title: "Designer Shorts Black",
      price: 35.00,
      image: "/placeholder.svg?height=400&width=400"
    },
    // More shorts...
  ],
  bags: [
    {
      id: 'bag-1',
      title: "Designer Bag Black",
      price: 115.00,
      image: "/placeholder.svg?height=400&width=400"
    },
    // More bags...
  ],
  hats: [
    {
      id: 'hat-1',
      title: "Designer Hat Black",
      price: 45.00,
      image: "/placeholder.svg?height=400&width=400"
    },
    // More hats...
  ]
}

export type Product = {
  id: string
  title: string
  price: number
  image: string
  isNew?: boolean
}

export type Category = keyof typeof products

